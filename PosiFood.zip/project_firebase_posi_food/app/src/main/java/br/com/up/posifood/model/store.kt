package br.com.up.posifood.model

import com.google.firebase.firestore.GeoPoint

data class store(
    var location: GeoPoint,
    var name:String,
    var menu:ArrayList<menuItem> = ArrayList()
    )
