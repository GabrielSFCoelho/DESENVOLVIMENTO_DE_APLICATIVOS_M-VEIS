package br.com.up.posifood.repository

import android.view.MenuItem
import android.view.ScrollCaptureCallback
import br.com.up.posifood.model.store
import com.google.android.gms.tasks.Task
import com.google.firebase.firestore.GeoPoint
import com.google.firebase.firestore.QuerySnapshot
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class StoryRepository {




    fun getAll(callback:(ArrayList<store>)-> Unit){
        val database =Firebase.firestore
        val  collection:Task <QuerySnapshot> = database.collection("Store").get()
        collection.addOnSuccessListener{ documents ->
             val stories = ArrayList<store>()
            for(document in documents){
                val name = document["name"] as String
                val menu = document["menu"] as ArrayList<HashMap<String, Any>>
                val location = document["location"] as GeoPoint

                val listStores = store(location, name)


                for(menuItem in menu){
                    val menuName = menuItem["name"] as String
                    val price = menuItem["price"] as Double
                    val description = menuItem["description"] as String

                    val MenuItem = menuItem(menuName, price, description)
                    store.menu.add(MenuItem)
                }
                listStores.add(store)
            }
            callback(listStores)

        }
    }
}