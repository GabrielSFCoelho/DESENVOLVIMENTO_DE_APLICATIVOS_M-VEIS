package br.com.up.posifood.model

import com.google.firebase.firestore.GeoPoint

data class menuItem(
    var description:String,
    var name:String,
    var price:Double
)
