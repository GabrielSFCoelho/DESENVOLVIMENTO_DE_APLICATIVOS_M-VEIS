package br.com.up.pokedex.model

 data class pokemon (
    val name : String,
    val url : String
)